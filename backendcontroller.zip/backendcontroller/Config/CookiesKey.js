//la cookies que vamos a enviar desde el backend al fronted
export const KeyValue = "PruebaCookiesDesdeBackend";